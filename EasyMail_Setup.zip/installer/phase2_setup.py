#!/usr/bin/env python3
"""EasyMail — Phase 2 : Configuration Python (pip, COM, config, Git, raccourci)"""

import subprocess
import sys
import os
import json

# ============================================================
#  Constantes
# ============================================================
EASYMAIL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(EASYMAIL_DIR, "config.json")
DEPS_FLAG = os.path.join(EASYMAIL_DIR, ".deps_installed")
STYLE_FILE = os.path.join(EASYMAIL_DIR, "style_profile.txt")
DB_FILE = os.path.join(EASYMAIL_DIR, "emails.db")

# Cle API Anthropic (injectee par build_zip.bat)
API_KEY = "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"

# Token Git read-only (injecte par build_zip.bat)
GIT_TOKEN = "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"
GIT_REPO = "github.com/Easymailpower/easymail.git"

REQUIRED_PACKAGES = ["flask==3.0.0", "anthropic==0.40.0", "pywin32==308"]
OPTIONAL_PACKAGES = ["PyPDF2", "python-docx", "openpyxl"]


def print_step(text, status=""):
    """Affiche une etape avec alignement."""
    if status:
        print(f"    → {text:<30s} {status}")
    else:
        print(f"  {text}")


def run_pip(package, quiet=True):
    """Installe un package pip. Retourne True si succes."""
    args = [sys.executable, "-m", "pip", "install", package]
    if quiet:
        args.append("--quiet")
    result = subprocess.run(args, capture_output=True, text=True)
    return result.returncode == 0


# ============================================================
#  2.1 — Verification pip
# ============================================================
print()
print("  Verification de pip...")
result = subprocess.run([sys.executable, "-m", "pip", "--version"],
                        capture_output=True, text=True)
if result.returncode != 0:
    print("    pip absent, reparation en cours...")
    subprocess.run([sys.executable, "-m", "ensurepip", "--upgrade"],
                   capture_output=True, text=True)
    # Re-verifier
    result = subprocess.run([sys.executable, "-m", "pip", "--version"],
                            capture_output=True, text=True)
    if result.returncode != 0:
        print("    ERREUR : pip n'a pas pu etre installe.")
        print("    Essayez : python -m ensurepip --upgrade")
        sys.exit(1)
print_step("pip", "OK")


# ============================================================
#  2.2 — Installation des dependances
# ============================================================
print()
print("  Installation des dependances...")

# Obligatoires
for pkg in REQUIRED_PACKAGES:
    name = pkg.split("==")[0]
    print(f"    → {name:<30s}", end=" ", flush=True)
    if run_pip(pkg):
        print("OK")
    else:
        print("ECHEC")
        print(f"\n    ERREUR : {name} est requis et n'a pas pu etre installe.")
        print("    Verifiez votre connexion internet et relancez install.bat")
        sys.exit(1)

# Optionnels
for pkg in OPTIONAL_PACKAGES:
    print(f"    → {pkg:<30s}", end=" ", flush=True)
    if run_pip(pkg):
        print("OK")
    else:
        print("optionnel")

print()


# ============================================================
#  2.3 — Post-install pywin32
# ============================================================
print("  Verification des modules COM...")
try:
    import win32com.client
    print_step("win32com.client", "OK")
except ImportError:
    print("    win32com absent, lancement du post-install pywin32...")
    # Trouver et lancer pywin32_postinstall.py
    scripts_dir = os.path.join(os.path.dirname(sys.executable), "Scripts")
    postinstall = os.path.join(scripts_dir, "pywin32_postinstall.py")
    if os.path.exists(postinstall):
        subprocess.run([sys.executable, postinstall, "-install"],
                       capture_output=True, text=True)
    # Aussi essayer via le module
    try:
        subprocess.run([sys.executable, "-c",
                        "import pywin32_postinstall; pywin32_postinstall.install()"],
                       capture_output=True, text=True)
    except Exception:
        pass

    # Re-tester
    try:
        import win32com.client
        print_step("win32com.client", "OK (apres post-install)")
    except ImportError:
        print("    ERREUR : win32com n'a pas pu etre charge.")
        print("    Essayez : pip install --force-reinstall pywin32")
        print("    Puis relancez install.bat")
        sys.exit(1)

try:
    import pythoncom
    print_step("pythoncom", "OK")
except ImportError:
    print("    ERREUR : pythoncom non disponible.")
    sys.exit(1)

print()


# ============================================================
#  2.4 — Test COM Outlook
# ============================================================
print("  Test connexion Outlook...")
try:
    import pythoncom
    import win32com.client

    pythoncom.CoInitialize()
    try:
        app = win32com.client.GetActiveObject("Outlook.Application")
    except Exception:
        app = win32com.client.Dispatch("Outlook.Application")

    ns = app.GetNamespace("MAPI")

    try:
        user = ns.CurrentUser.Name
        print_step(f"Utilisateur : {user}", "")
    except Exception:
        print_step("Utilisateur : inconnu", "")

    try:
        inbox = ns.GetDefaultFolder(6)  # olFolderInbox
        count = inbox.Items.Count
        print_step(f"Boite de reception : {count} messages", "")
        print_step("Connexion COM", "OK")
    except Exception as e:
        err = str(e)
        if "GetDefaultFolder" in err or "MAPI" in err:
            print("    Outlook est ouvert mais aucun compte n'est configure.")
            print("    Ajoutez votre compte email dans Outlook puis relancez install.bat.")
            pythoncom.CoUninitialize()
            sys.exit(1)
        else:
            print(f"    Avertissement : {err}")
            print("    EasyMail sera installe mais lancez Outlook avant de le demarrer.")

    pythoncom.CoUninitialize()

except Exception as e:
    print(f"    Echec de connexion : {e}")
    print("    EasyMail sera installe mais Outlook doit etre ouvert au demarrage.")

print()


# ============================================================
#  2.5 — Verification Windows Search
# ============================================================
print("  Verification du service Windows Search...")
try:
    result = subprocess.run(["sc", "query", "WSearch"],
                            capture_output=True, text=True)
    if "RUNNING" in result.stdout:
        print_step("Windows Search", "OK")
    elif "STOPPED" in result.stdout:
        print("    Windows Search est arrete.")
        print("    La recherche dans les anciens emails sera limitee.")
        print("    Pour l'activer : Services → Windows Search → Demarrer")
    else:
        print_step("Windows Search", "non determine")
except Exception:
    print_step("Windows Search", "non verifie")

print()


# ============================================================
#  2.6 — Clone / init repo Git
# ============================================================
git_ok = len(sys.argv) > 1 and sys.argv[1] == "1"

if git_ok:
    print("  Configuration des mises a jour automatiques...")

    os.chdir(EASYMAIL_DIR)
    is_git_repo = subprocess.run(["git", "rev-parse", "--git-dir"],
                                 capture_output=True, text=True).returncode == 0

    if is_git_repo:
        # Deja un repo Git → pull
        print("    Depot Git existant, mise a jour...")
        result = subprocess.run(["git", "pull", "--quiet"],
                                capture_output=True, text=True)
        if result.returncode == 0:
            print_step("Mises a jour", "OK (depot existant)")
        else:
            print_step("Mises a jour", "OK (depot existant, pull differe)")
    else:
        # Initialiser le repo Git a partir du dossier existant
        if GIT_TOKEN != "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":
            remote_url = f"https://{GIT_TOKEN}@{GIT_REPO}"
            print("    Initialisation du depot Git...")

            subprocess.run(["git", "init", "--quiet"], capture_output=True, text=True)
            subprocess.run(["git", "remote", "add", "origin", remote_url],
                           capture_output=True, text=True)

            result = subprocess.run(["git", "fetch", "--quiet", "origin"],
                                    capture_output=True, text=True)
            if result.returncode == 0:
                # Aligner sur la branche main
                subprocess.run(["git", "checkout", "-B", "main", "origin/main", "--quiet"],
                               capture_output=True, text=True)
                print_step("Mises a jour automatiques", "OK")
            else:
                print("    Echec de la connexion au depot distant.")
                print("    Les mises a jour automatiques ne seront pas disponibles.")
                # Nettoyer le .git inutile
                import shutil
                git_dir = os.path.join(EASYMAIL_DIR, ".git")
                if os.path.isdir(git_dir):
                    shutil.rmtree(git_dir, ignore_errors=True)
        else:
            print("    Token Git non configure.")
            print("    Les mises a jour automatiques ne seront pas disponibles.")
else:
    print("  Git non disponible — mises a jour automatiques desactivees.")

print()


# ============================================================
#  2.7 — Creation config.json
# ============================================================
print("  Configuration de la cle API...")

if os.path.exists(CONFIG_PATH):
    # Verifier que la cle est valide
    try:
        with open(CONFIG_PATH, "r") as f:
            config = json.load(f)
        key = config.get("ANTHROPIC_API_KEY", "")
        if key and "COLLER_ICI" not in key and key.startswith("sk-"):
            print_step("config.json existant preserve", "OK")
        else:
            # Cle invalide → remplacer
            if API_KEY != "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":
                config["ANTHROPIC_API_KEY"] = API_KEY
                with open(CONFIG_PATH, "w") as f:
                    json.dump(config, f, indent=2)
                print_step("Cle API mise a jour", "OK")
            else:
                print("    ATTENTION : La cle API n'est pas configuree dans config.json.")
                print("    Demandez la cle a Yvan.")
    except Exception:
        pass
else:
    # Creer config.json
    if API_KEY != "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":
        config = {"ANTHROPIC_API_KEY": API_KEY}
        with open(CONFIG_PATH, "w") as f:
            json.dump(config, f, indent=2)
        print_step("config.json cree", "OK")
    else:
        # Mode dev : creer avec placeholder
        config = {"ANTHROPIC_API_KEY": "COLLER_ICI_VOTRE_CLE_ANTHROPIC"}
        with open(CONFIG_PATH, "w") as f:
            json.dump(config, f, indent=2)
        print("    config.json cree avec un placeholder.")
        print("    Remplacez COLLER_ICI_VOTRE_CLE_ANTHROPIC par votre cle dans config.json")

print()


# ============================================================
#  2.8 — Preservation des donnees existantes
# ============================================================
# Rien a faire : les fichiers sont dans .gitignore
# On s'assure juste que les fichiers critiques ne sont pas ecrases
preserved = []
if os.path.exists(DB_FILE):
    preserved.append("emails.db")
if os.path.exists(STYLE_FILE):
    preserved.append("style_profile.txt")
if preserved:
    print(f"  Donnees existantes preservees : {', '.join(preserved)}")
    print()


# ============================================================
#  2.9 — Raccourci bureau
# ============================================================
print("  Creation du raccourci bureau...")
try:
    import win32com.client

    shell = win32com.client.Dispatch("WScript.Shell")

    # Methode fiable : SpecialFolders (gere OneDrive, GP redirect, etc.)
    desktop = shell.SpecialFolders("Desktop")

    shortcut_path = os.path.join(desktop, "EasyMail.lnk")
    start_bat = os.path.join(EASYMAIL_DIR, "start.bat")

    shortcut = shell.CreateShortCut(shortcut_path)
    shortcut.TargetPath = start_bat
    shortcut.WorkingDirectory = EASYMAIL_DIR
    shortcut.Description = "EasyMail — Assistant email intelligent"

    # Icone enveloppe (shell32.dll index 19)
    system_root = os.environ.get("SystemRoot", r"C:\Windows")
    shortcut.IconLocation = os.path.join(system_root, "System32", "shell32.dll") + ",19"
    shortcut.save()

    print_step(f"Raccourci cree : {shortcut_path}", "OK")
except Exception as e:
    print(f"    Echec creation raccourci : {e}")
    print(f"    Vous pouvez creer un raccourci manuellement vers :")
    print(f"    {os.path.join(EASYMAIL_DIR, 'start.bat')}")

print()


# ============================================================
#  2.10 — Warning OneDrive
# ============================================================
if "\\OneDrive\\" in EASYMAIL_DIR or "\\OneDrive " in EASYMAIL_DIR:
    print("  ============================================")
    print("  NOTE : EasyMail est dans un dossier OneDrive.")
    print("  La synchronisation OneDrive peut parfois entrer")
    print("  en conflit avec la base de donnees locale.")
    print("  Si vous rencontrez des lenteurs, deplacez le")
    print("  dossier EasyMail dans C:\\EasyMail")
    print("  ============================================")
    print()


# ============================================================
#  2.11 — Flag .deps_installed
# ============================================================
with open(DEPS_FLAG, "w") as f:
    f.write("ok")


# ============================================================
#  2.12 — Message final
# ============================================================
print()
print("========================================")
print("  Installation terminee !")
print("========================================")
print()
print("  Pour lancer EasyMail :")
print('    → Double-cliquez "EasyMail" sur votre bureau')
print()
print("  Avant le premier lancement :")
print("    → Outlook doit etre ouvert")
print("    → Internet doit etre connecte")
print()
print("  Premier lancement : EasyMail analysera vos emails")
print("  pendant 2-3 minutes pour apprendre votre style.")
print()
print("  Les mises a jour sont automatiques a chaque")
print("  demarrage d'EasyMail. Rien a faire !")
print()
print("========================================")
print()
